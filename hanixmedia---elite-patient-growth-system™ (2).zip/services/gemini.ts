
import { GoogleGenAI } from "@google/genai";
import { Insight, QuizResult, UserLocation } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getClinicMarketInsights = async (topic: string = "Patient acquisition for aesthetic clinics"): Promise<Insight> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Provide a highly relevant, data-driven report for U.S. cosmetic clinic owners regarding ${topic}. Focus on patient behavior, regional demand, and modern booking tech for 2024/2025. Mention specific procedural growth trends like Semaglutide, Laser Hair Removal, or high-ticket surgery if relevant.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "Market data analysis pending.";
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    const sources = chunks
      .map((chunk: any) => ({
        title: chunk.web?.title || "Market Intelligence Source",
        uri: chunk.web?.uri || ""
      }))
      .filter((source: any) => source.uri !== "");

    return {
      content: text,
      sources: sources
    };
  } catch (error) {
    console.error("Gemini Market Intel Error:", error);
    return {
      content: "Unable to sync real-time medical aesthetic trends. Please re-engage.",
      sources: []
    };
  }
};

interface ChatContext {
  quizResult: QuizResult | null;
  userLocation: UserLocation | null;
}

export const createChatSession = (context: ChatContext) => {
  
  let systemContext = `You are the HanixMedia Strategic Growth AI Assistant. You assist U.S. cosmetic clinic owners and surgeons in understanding the Patient Growth System™. Your tone is elite, professional, clinical, and high-ticket.`;

  if (context.userLocation) {
    systemContext += ` The user is located in ${context.userLocation.city}, ${context.userLocation.region}. Be relevant to their specific market competition level.`;
  }

  if (context.quizResult) {
    systemContext += ` CRITICAL: The user has completed a diagnostic audit. Their score is ${context.quizResult.score}/100. 
    They have an estimated revenue leak of $${context.quizResult.leakEstimate}/month.
    Their specific category scores are:
    - Acquisition: ${context.quizResult.categoryScores.acquisition}%
    - Conversion: ${context.quizResult.categoryScores.conversion}%
    - Retention: ${context.quizResult.categoryScores.retention}%
    
    Reference these specific numbers. If their score is low (<60), be urgent and warn about "structural failure". If high (>80), compliment their "elite baseline" but suggest "optimization".`;
  } else {
    systemContext += ` The user has NOT taken the audit yet. Encourage them to "Initialize the Diagnostic Terminal" to get their specific Growth Score.`;
  }

  systemContext += ` Discourage bargain hunters. Emphasize that HanixMedia works only on high-ticket, high-authority clinical yield cases.`;

  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: systemContext,
      thinkingConfig: {
        thinkingBudget: 32768
      }
    }
  });
};
