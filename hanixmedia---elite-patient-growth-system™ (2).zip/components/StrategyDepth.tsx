import React from 'react';

export const StrategyDepth: React.FC = () => {
  return (
    <section id="protocols-detail" className="py-48 px-8 bg-white relative border-y border-neutral-50">
       <div className="max-w-[1400px] mx-auto space-y-32">
         <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-end">
            <div className="lg:col-span-8 space-y-6">
               <div className="flex items-center gap-4">
                  <span className="w-10 h-px bg-indigo-600/30"></span>
                  <p className="cinematic-caps text-indigo-600 font-bold tracking-[0.4em]">Clinical Service Protocol</p>
               </div>
               <h2 className="luxury-header text-obsidian uppercase italic tracking-tight">
                 Strategic <span className="font-bold">Extraction.</span>
               </h2>
            </div>
            <div className="lg:col-span-4 border-l border-neutral-100 pl-8">
               <p className="text-lg text-slate-400 font-light leading-relaxed italic">
                 Standard ads drive clicks. We build the recapturing logic infrastructure to translate demand into surgical outcomes.
               </p>
            </div>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-neutral-100 border border-neutral-100">
            {[
              { 
                title: 'Yield Mapping', 
                desc: 'Syncing proprietary clinical intake demand for regional high-ticket surgical search nodes.',
                bench: 'Target Procedural Intent'
              },
              { 
                title: 'Latency Fix', 
                desc: 'Advanced logistical intake recapture synchronizing speed with HIPAA follow-up protocols.',
                bench: '94% Show-up Health'
              },
              { 
                title: 'Market Exclusivity', 
                desc: 'Partnership lockout for clinical surgical categories in your specific geographical extraction node.',
                bench: '1:1 Regional Partner'
              }
            ].map((strategy, idx) => (
              <div key={idx} className="bg-white p-12 space-y-10 hover:bg-neutral-50 transition-all group">
                <div className="flex justify-between items-center">
                   <div className="w-10 h-px bg-indigo-600/10 group-hover:w-16 transition-all"></div>
                   <span className="text-[9px] font-mono text-neutral-200 uppercase font-black tracking-widest">MOD_0{idx + 1}</span>
                </div>
                <div className="space-y-4">
                  <h3 className="text-3xl font-display font-bold text-obsidian uppercase tracking-tight italic">{strategy.title}</h3>
                  <p className="text-lg text-slate-400 font-light leading-relaxed h-24">{strategy.desc}</p>
                </div>
                <div className="pt-8 border-t border-neutral-50 flex items-center gap-3">
                   <span className="w-1 h-1 bg-indigo-600"></span>
                   <span className="cinematic-caps text-indigo-600 text-[8px] font-bold tracking-[0.3em] uppercase">{strategy.bench}</span>
                </div>
              </div>
            ))}
         </div>
       </div>
    </section>
  );
};