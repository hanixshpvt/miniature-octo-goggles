
import React, { useState, useEffect } from 'react';
import { getClinicMarketInsights } from '../services/gemini';
import { useAppStore } from '../context';

export const InsightSection: React.FC = () => {
  const { marketInsight, setMarketInsight, insightTopic, setInsightTopic } = useAppStore();
  const [loading, setLoading] = useState<boolean>(false);

  const fetchInsights = async () => {
    setLoading(true);
    const data = await getClinicMarketInsights(insightTopic);
    setMarketInsight(data);
    setLoading(false);
  };

  // Only fetch if we don't have data yet
  useEffect(() => { 
    if (!marketInsight) {
      fetchInsights(); 
    }
  }, []);

  return (
    <section className="py-40 lg:py-80 px-8 bg-white border-y border-slate-100 grid-mask overflow-hidden">
      <div className="max-w-[1600px] mx-auto space-y-32">
        
        <div className="text-center space-y-12 reveal">
           <p className="cinematic-caps text-indigo-700 font-black tracking-[0.7em] uppercase text-[11px]">Secure Strategic Extract node</p>
           <h2 className="luxury-header text-obsidian italic">Strategic <br/><span className="font-bold underline decoration-slate-100 underline-offset-[25px]">Surveillance.</span></h2>
           <p className="text-2xl text-slate-500 max-w-2xl mx-auto font-light italic leading-relaxed">Structural surgical demand monitoring synchronized via secure clinical extraction nodes.</p>
        </div>

        <div className="relative group p-1 bg-slate-50 shadow-5xl overflow-hidden border border-slate-100 rounded-sm reveal">
          <div className="bg-[#020617] text-white p-12 lg:p-28 space-y-20 border border-white/5 relative">
            
            <div className="absolute top-0 right-0 p-12 opacity-[0.03] text-[120px] font-display italic pointer-events-none select-none uppercase font-black tracking-tighter">NODE_PGS</div>

            {/* Terminal Diagnostic Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-white/10 pb-16 gap-10 relative z-10">
              <div className="flex items-center gap-10">
                 <div className="flex gap-2">
                    <span className="w-3.5 h-3.5 bg-indigo-600 animate-pulse rounded-sm"></span>
                    <span className="w-3.5 h-3.5 bg-white/10 rounded-sm"></span>
                    <span className="w-3.5 h-3.5 bg-white/10 rounded-sm"></span>
                 </div>
                 <span className="text-[11px] tracking-[0.6em] uppercase text-white font-black">Secure Feed Ingest :: [LIVE_SCAN_NODE]</span>
              </div>
              
              <div className="flex items-center gap-6 w-full md:w-auto p-1 bg-white/5 border border-white/10 group-hover:border-indigo-600/30 transition-all">
                 <input 
                   className="bg-transparent border-none px-8 py-5 text-[12px] tracking-[0.3em] text-indigo-400 focus:ring-0 w-full md:w-[480px] font-mono font-black uppercase placeholder:opacity-20"
                   value={insightTopic}
                   onChange={(e) => setInsightTopic(e.target.value)}
                   placeholder="SCAN_QUERY..."
                 />
                 <button onClick={fetchInsights} disabled={loading} className="px-14 py-5 bg-white text-obsidian font-black text-[10px] hover:bg-indigo-600 hover:text-white transition-all cinematic-caps">
                   {loading ? 'SYNCING...' : 'RE-SCAN TERMINAL'}
                 </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-24 items-start pt-10 relative z-10">
              <div className="lg:col-span-8 space-y-16">
                 {loading ? (
                   <div className="space-y-14 opacity-30">
                      {[1,2,3,4,5].map(i => (
                        <div key={i} className="h-px bg-indigo-500 w-full animate-pulse" style={{ animationDelay: `${i * 300}ms` }}></div>
                      ))}
                      <p className="text-[12px] tracking-[0.8em] animate-pulse cinematic-caps text-center text-white font-bold uppercase">Recalibrating regional clinical procedural intent scan nodes...</p>
                   </div>
                 ) : (
                   <div className="text-[1.8rem] md:text-[2.2rem] leading-[2.0] text-slate-300 font-light italic tracking-tight border-l-[6px] border-indigo-700 pl-16 py-6 whitespace-pre-line reveal">
                     {marketInsight?.content || "Market synchronization active. Awaiting strategic query."}
                   </div>
                 )}
              </div>

              <div className="lg:col-span-4 border-l border-white/5 pl-16 hidden lg:block space-y-16 min-h-[450px]">
                 <p className="text-[12px] cinematic-caps text-white font-bold tracking-[0.6em] uppercase underline decoration-indigo-600 decoration-4 underline-offset-8 mb-10">Verification_Nodes</p>
                 <div className="space-y-14">
                   {(!marketInsight || marketInsight.sources.length === 0) ? (
                     <p className="text-xs text-slate-500 italic">Strategic intel sync scan pending diagnostic calib ingress.</p>
                   ) : marketInsight.sources.map((s, i) => (
                     <a key={i} href={s.uri} target="_blank" className="block group border-b border-white/5 pb-10 hover:border-indigo-600 transition-all">
                       <p className="text-[10px] text-indigo-600 cinematic-caps mb-4 tracking-widest font-black uppercase">SYNC_SOURCE_PGS_0{i+1}</p>
                       <span className="text-2xl text-slate-100 font-display italic underline decoration-transparent group-hover:decoration-indigo-600/40 transition-all block truncate">
                         {s.title}
                       </span>
                     </a>
                   ))}
                 </div>
              </div>
            </div>

            <div className="pt-20 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-[11px] cinematic-caps tracking-[0.6em] font-bold uppercase text-white opacity-20 gap-8">
               <span>GEMINI_SURVEILLANCE_TERMINAL_SYNC_V4</span>
               <span className="italic font-light">INGRESS_NODE_TS :: {new Date().toLocaleTimeString()}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
