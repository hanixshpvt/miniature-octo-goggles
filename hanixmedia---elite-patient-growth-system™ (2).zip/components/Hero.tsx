
import React from 'react';
import { useAppStore } from '../context';

interface HeroProps {
  onStartQuiz: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onStartQuiz }) => {
  const { userLocation } = useAppStore();

  return (
    <section className="relative min-h-[90vh] lg:min-h-screen flex items-center overflow-hidden grid-mask border-b border-slate-100">
      <div className="max-w-[1700px] mx-auto w-full px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-32 items-center py-12 md:py-24">
        
        {/* Authoritative Outcome Column */}
        <div className="lg:col-span-7 space-y-10 md:space-y-20 reveal order-2 lg:order-1">
          <div className="space-y-6 md:space-y-12">
            <div className="flex items-center gap-6 md:gap-8">
              <span className="w-10 md:w-14 h-1.5 bg-indigo-600"></span>
              <h2 className="cinematic-caps text-obsidian font-black tracking-[0.3em] md:tracking-[0.5em] text-[10px] md:text-xs">
                {userLocation 
                  ? `${userLocation.city} // ${userLocation.region} // CLINICAL VERIFICATION NODE` 
                  : "US Clinical Verification node :: VERIFIED_PGS"}
              </h2>
            </div>
            <h1 className="luxury-header italic text-obsidian uppercase leading-[1.1]">
              Guaranteed <br />
              <span className="font-bold border-b-[12px] md:border-b-[20px] border-slate-100 leading-none">
                {userLocation ? `${userLocation.city} Patients.` : "Booked Patients."}
              </span>
            </h1>
          </div>
          
          <div className="space-y-10 md:space-y-16">
            <p className="readable-desc text-obsidian max-w-2xl border-l-[8px] md:border-l-[12px] border-indigo-600 pl-8 md:pl-16 italic font-light text-lg md:text-xl leading-relaxed">
              Structural revenue recovery architecture for {userLocation ? `elite ${userLocation.city}` : "aesthetic"} surgeons. We synchronize extraction nodes to restore margin physics — <span className="font-bold underline decoration-indigo-600 decoration-[4px] md:decoration-[6px] underline-offset-4 md:underline-offset-8">guaranteed booked appointments or you don't pay.</span>
            </p>
            
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-8 md:gap-20">
              <button onClick={onStartQuiz} className="btn-luxury px-12 md:px-24 w-full sm:w-auto shadow-2xl py-5 md:py-6 text-[11px] md:text-xs group">
                <span className="group-hover:text-indigo-200 transition-colors">Unlock Growth Score</span> 
                <span className="ml-4 group-hover:translate-x-2 transition-transform inline-block">→</span>
              </button>
              
              <div className="flex flex-col gap-2 pl-8 md:pl-12 border-l-2 border-slate-100">
                <span className="cinematic-caps text-slate-400 font-black tracking-[0.4em] md:tracking-[0.6em] text-[9px] md:text-[11px]">EST_NODE EXTRACTION TARGET</span>
                <span className="text-3xl md:text-5xl font-display italic font-bold text-obsidian tracking-tighter">
                  +$140,000 / MO Gaps
                </span>
              </div>
            </div>
          </div>

          {/* Sequential trust markers */}
          <div className="flex flex-wrap items-center gap-6 md:gap-12 opacity-60 reveal" style={{ animationDelay: '0.8s' }}>
             <div className="flex items-center gap-3 md:gap-4 reveal" style={{ animationDelay: '1.0s' }}>
                <span className="w-2 h-2 md:w-2.5 md:h-2.5 rounded-full bg-green-500 animate-pulse"></span>
                <p className="cinematic-caps text-[9px] md:text-[10px] font-black text-obsidian">Recapture Sync Active</p>
             </div>
             <div className="flex items-center gap-3 md:gap-4 reveal" style={{ animationDelay: '1.2s' }}>
                <div className="w-4 md:w-6 h-px bg-obsidian"></div>
                <p className="cinematic-caps text-[9px] md:text-[10px] font-black text-obsidian">Exclusivity Partner Logic</p>
             </div>
          </div>
        </div>

        {/* High-Fidelity Clinical Visual Anchor */}
        <div className="lg:col-span-5 h-[400px] lg:h-[85vh] relative reveal group border-2 border-slate-50 shadow-5xl order-1 lg:order-2 w-full" style={{ animationDelay: '0.4s' }}>
           <div className="absolute inset-0 bg-slate-50 z-0"></div>
           <img 
            src="https://images.unsplash.com/photo-1666214280557-f1b5022eb634?auto=format&fit=crop&q=80&w=1400" 
            alt="Elite Clinical Aesthetic Space" 
            className="w-full h-full object-cover grayscale opacity-95 group-hover:grayscale-0 transition-all duration-[8s] scale-100 group-hover:scale-110"
            loading="lazy"
          />
          {/* Mobile-Optimized Floating Card: Inset on mobile, Outset left on desktop */}
          <div className="absolute bottom-6 left-6 right-6 lg:top-1/2 lg:bottom-auto lg:left-[-6rem] lg:right-auto lg:-translate-y-1/2 bg-white p-8 lg:p-20 shadow-5xl border border-slate-50 z-20 space-y-4 lg:space-y-10 max-w-none lg:max-w-[450px]">
             <p className="cinematic-caps text-indigo-700 text-[9px] lg:text-[11px] font-black tracking-[0.4em] lg:tracking-[0.6em] mb-2 lg:mb-4">Ingress hub verification</p>
             <h3 className="text-5xl lg:text-9xl font-display font-bold italic text-obsidian tracking-tighter leading-none">7.5X ROI</h3>
             <p className="text-[9px] lg:text-[11px] cinematic-caps text-slate-400 font-bold tracking-[0.4em] lg:tracking-[0.5em] uppercase">{userLocation ? `${userLocation.city.toUpperCase()} HUB AUDIT` : "Miami Surgical Hub Audit"} // 2024</p>
          </div>
        </div>

      </div>
    </section>
  );
};
