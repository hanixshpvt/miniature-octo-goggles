import React from 'react';

interface Props {
  onStartQuiz: () => void;
}

export const CaseStudies: React.FC<Props> = ({ onStartQuiz }) => {
  const cases = [
    {
      id: 'case-1',
      title: 'Beverly Hills Aesthetics',
      result: '7.5X',
      metric: 'ROI_RECOVERY',
      img: 'https://images.unsplash.com/photo-1631217816611-204ef387f31c?auto=format&fit=crop&q=80&w=1200',
      testimonial: '"Structural procedural intent-loss detected and recaptured within 14 days. Hanix turned cold digital signals into high-ticket surgery room reality. Authoritative recapture physics."',
      meta: 'DR. S. VAN DER HOEK // SURGICAL Hub DIRECTOR',
      details: '11 SURGICAL APPOINTMENTS / 14 DAYS',
      spark: [15, 35, 25, 65, 55, 95, 88, 120]
    },
    {
      id: 'case-2',
      title: 'Miami Clinical Recuperation',
      result: '$140k',
      metric: 'MARGIN_SYNC',
      img: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&q=80&w=1200',
      testimonial: '"Strategic triage synchronization for our ingest recapturing system forced procedural extraction markers to sync. Show-up yield stabilized immediately across extraction nodes."',
      meta: 'MEDICAL HUB DIRECTOR // MIAMI SURGICAL',
      details: 'SHOW-UP YIELD RECAP +42%',
      spark: [20, 45, 65, 50, 85, 95, 105, 140]
    }
  ];

  return (
    <section className="py-40 md:py-80 px-6 lg:px-12 bg-white border-y border-slate-50" id="evidence">
      <div className="max-w-[1700px] mx-auto space-y-48 md:space-y-64">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-48 items-end reveal">
          <div className="lg:col-span-8 space-y-12">
            <div className="flex items-center gap-12">
              <span className="w-24 h-2 bg-indigo-600"></span>
              <p className="cinematic-caps text-indigo-950 font-black text-[12px] tracking-[0.6em]">Structural Ledger Verification</p>
            </div>
            <h2 className="luxury-header text-obsidian italic">Evidence <br /><span className="font-bold border-b-[30px] border-slate-50 underline-offset-[25px]">Recapture Ledgers.</span></h2>
          </div>
          <div className="lg:col-span-4 border-l-[12px] border-indigo-600 pl-16 py-8 bg-slate-50">
            <p className="text-2xl text-obsidian italic font-bold leading-relaxed max-w-sm">
              Verified patient show-up yield audited across elite US clinical Hubs. Partnership nodes locked.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-slate-200 border-2 border-slate-200 shadow-5xl overflow-hidden rounded-sm">
          {cases.map((c, idx) => (
            <div key={c.id} className="bg-white p-12 lg:p-24 space-y-20 group hover:bg-slate-50 transition-all duration-[1500ms]">
              <div className="aspect-[16/9] overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-1000 border border-slate-100 relative shadow-2xl">
                <img src={c.img} alt={c.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[8s]" />
                <div className="absolute top-0 left-0 bg-obsidian text-white p-5 cinematic-caps text-[10px] tracking-widest font-black">NODE_0{idx+1}</div>
              </div>

              <div className="space-y-8">
                 <span className="cinematic-caps text-indigo-700 text-[11px] font-black tracking-[0.5em] uppercase border-b-2 border-slate-50 pb-2">Verified Yield Protocol Hub</span>
                 <h3 className="text-4xl md:text-5xl font-display font-bold italic text-obsidian uppercase tracking-tighter group-hover:tracking-normal transition-all">{c.title}</h3>
                 <div className="text-8xl md:text-[10rem] font-black font-display text-obsidian group-hover:text-indigo-900 transition-all duration-[2s] leading-none tracking-tighter">{c.result}</div>
                 <p className="text-[11px] cinematic-caps text-slate-500 font-bold tracking-[0.8em] border-t border-slate-100 pt-4 uppercase">{c.metric}</p>
              </div>

              {/* Enhanced Visual Sparkline */}
              <div className="h-32 w-full pt-10 border-t border-slate-100 opacity-80 group-hover:opacity-100 group-hover:border-indigo-600 transition-all relative">
                 <svg viewBox="0 0 100 50" className="w-full h-full drop-shadow-[0_10px_10px_rgba(79,70,229,0.3)]">
                    <path 
                      d={`M 0 ${50 - c.spark[0] / 3} ${c.spark.map((v, i) => `L ${i * (100 / (c.spark.length - 1))} ${50 - v / 3}`).join(' ')}`} 
                      fill="none" stroke="#4f46e5" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" 
                      className="animate-draw" 
                    />
                 </svg>
              </div>

              <div className="pt-16 space-y-12 border-t border-slate-50">
                 <blockquote className="text-2xl md:text-3xl text-obsidian italic font-bold leading-relaxed border-l-[10px] border-slate-100 pl-12">"{c.testimonial}"</blockquote>
                 <div className="space-y-6">
                    <p className="cinematic-caps text-obsidian text-[12px] font-black tracking-[0.5em] uppercase underline decoration-indigo-600 decoration-4 underline-offset-8">{c.meta}</p>
                    <div className="flex items-center gap-6">
                       <span className="w-4 h-4 rounded-full bg-indigo-600 animate-pulse shadow-[0_0_15px_rgba(79,70,229,1)]"></span>
                       <p className="text-[11px] cinematic-caps text-indigo-950 font-black tracking-[0.4em] uppercase">{c.details}</p>
                    </div>
                 </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-center pt-12 reveal">
           <button onClick={onStartQuiz} className="btn-luxury px-24 py-10 shadow-3xl text-[12px] group tracking-[0.5em]">Request Structural Hub Diagnostic Access Node <span className="ml-10 group-hover:translate-x-6 transition-transform">::</span></button>
        </div>
      </div>
    </section>
  );
};