import React, { useState, useEffect } from 'react';

interface NavbarProps {
  onStartQuiz: () => void;
  onNavigate: (view: string) => void;
  currentView: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onStartQuiz, onNavigate, currentView }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNav = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className={`fixed top-0 w-full z-[100] transition-all duration-1000 h-[var(--header-h)] flex items-center ${scrolled ? 'bg-white border-b border-slate-100 shadow-xl py-2' : 'bg-white py-4'}`}>
      <div className="max-w-[1700px] mx-auto w-full px-6 md:px-12 flex justify-between items-center">
        
        {/* Authoritative Brand Crest */}
        <div onClick={() => handleNav('home')} className="flex items-center gap-5 cursor-pointer group active:scale-[0.98] transition-transform">
          <div className="w-10 h-10 md:w-14 md:h-14 border-[3px] border-obsidian flex items-center justify-center relative bg-white group-hover:border-indigo-600 transition-all duration-700">
             <svg viewBox="0 0 100 100" className="w-6 h-6 md:w-8 md:h-8 relative z-10 fill-obsidian group-hover:fill-indigo-700 transition-all">
                <path d="M50 0 L100 50 L50 100 L0 50 Z" />
             </svg>
          </div>
          <div className="flex flex-col -space-y-1">
             <span className="text-xl md:text-2xl font-display font-bold italic uppercase text-obsidian tracking-tighter">HANIX<span className="text-indigo-800 font-light">MEDIA</span></span>
             <span className="text-[8px] md:text-[10px] cinematic-caps text-obsidian/60 font-black tracking-[0.5em]">GROWTH PARTNER™</span>
          </div>
        </div>

        {/* Semantic Desktop Navigation */}
        <nav className="hidden xl:flex items-center gap-12 cinematic-caps text-[11px] font-black text-obsidian">
          {[
            { n: 'Recapture Protocol', id: 'services' },
            { n: 'Evidence Ledger', id: 'cases' },
            { n: 'About Partner', id: 'about' }
          ].map(l => (
            <button 
              key={l.id} 
              onClick={() => handleNav(l.id)} 
              className={`hover:text-indigo-600 transition-all tracking-[0.4em] px-3 relative group ${currentView === l.id ? 'text-indigo-600' : ''}`}
            >
              {l.n}
              <span className={`absolute -bottom-2 left-1/2 -translate-x-1/2 h-[4px] bg-indigo-600 transition-all duration-500 ${currentView === l.id ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
            </button>
          ))}
        </nav>

        {/* Conversion Node */}
        <div className="flex items-center gap-6">
          <button 
            onClick={onStartQuiz}
            className="btn-luxury hidden lg:flex text-[11px] py-4 px-12 group border-2 border-obsidian"
          >
            INITIALIZE AUDIT ::
          </button>
          
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
            className="xl:hidden w-12 h-12 flex flex-col items-center justify-center gap-2 z-[110]"
            aria-label="Toggle Menu"
          >
            <span className={`w-8 h-[3px] bg-obsidian transition-all duration-500 ${mobileMenuOpen ? 'rotate-45 translate-y-[11px]' : ''}`}></span>
            <span className={`w-8 h-[3px] bg-obsidian transition-all duration-500 ${mobileMenuOpen ? 'opacity-0' : ''}`}></span>
            <span className={`w-8 h-[3px] bg-obsidian transition-all duration-500 ${mobileMenuOpen ? '-rotate-45 -translate-y-[11px]' : ''}`}></span>
          </button>
        </div>
      </div>

      {/* High-Impact Mobile Drawer */}
      <div className={`fixed inset-0 bg-white transition-all duration-1000 ease-[cubic-bezier(0.16,1,0.3,1)] z-[100] flex flex-col ${mobileMenuOpen ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-full pointer-events-none'}`}>
        <div className="flex flex-col h-full pt-40 px-8 pb-12 overflow-y-auto">
          <div className="flex flex-col gap-12">
             {[
              { n: 'Recovery protocols', id: 'services' },
              { n: 'Evidence ledger', id: 'cases' },
              { n: 'Partnership', id: 'about' },
              { n: 'Structural Audit', id: 'contact' }
            ].map((l, i) => (
              <button 
                key={l.id} 
                onClick={() => handleNav(l.id)}
                className="text-4xl sm:text-5xl font-display font-bold italic text-obsidian uppercase text-left group"
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                {l.n}<span className="text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity">.</span>
              </button>
            ))}
          </div>
          
          <div className="mt-auto space-y-10 pt-16">
             <button onClick={() => { onStartQuiz(); setMobileMenuOpen(false); }} className="btn-luxury w-full text-center py-8 text-[12px] bg-obsidian">
                Unlock diagnostic audit ::
             </button>
             <div className="flex items-center justify-between text-[11px] cinematic-caps text-slate-400 font-black uppercase tracking-widest">
                <span className="flex items-center gap-3"><span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-pulse"></span> US_PGS_9.2</span>
                <span>HIPAA Verified node</span>
             </div>
          </div>
        </div>
      </div>
    </header>
  );
};