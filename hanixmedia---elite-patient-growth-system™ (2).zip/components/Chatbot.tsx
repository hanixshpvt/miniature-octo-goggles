
import React, { useState, useEffect, useRef } from 'react';
import { createChatSession } from '../services/gemini';
import { GenerateContentResponse } from '@google/genai';
import { useAppStore } from '../context';

export const Chatbot: React.FC = () => {
  const { quizResult, userLocation } = useAppStore();
  const [isOpen, setIsOpen] = useState(false);
  
  // Dynamic greeting based on context
  const getInitialMessage = () => {
    if (quizResult && quizResult.score < 60) {
      return `WARNING: Diagnostic score of ${quizResult.score} detected. Structural revenue leaks identified. How can I assist with immediate triage?`;
    }
    if (quizResult) {
      return `Diagnostic complete. Score: ${quizResult.score}/100. Revenue recovery nodes initialized. Proceed with strategic inquiry.`;
    }
    return 'Diagnostic Terminal active. Initialize consultation regarding your structural yield gaps.';
  }

  const [messages, setMessages] = useState<{ role: 'user' | 'bot', text: string }[]>([
    { role: 'bot', text: getInitialMessage() }
  ]);
  
  // Reset message when quiz result changes
  useEffect(() => {
    setMessages([{ role: 'bot', text: getInitialMessage() }]);
    setChat(null); // Force recreation of session with new context
  }, [quizResult]);

  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chat, setChat] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  useEffect(() => {
    if (isOpen && !chat) {
      // Inject global context into the AI session
      setChat(createChatSession({ quizResult, userLocation }));
    }
  }, [isOpen, chat, quizResult, userLocation]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await chat.sendMessage({ message: userMsg }) as GenerateContentResponse;
      setMessages(prev => [...prev, { role: 'bot', text: response.text || 'Synchronization lost. Re-initializing...' }]);
    } catch (error) {
      console.error("Chat error:", error);
      setMessages(prev => [...prev, { role: 'bot', text: 'Audit node error. Strategic feed disrupted.' }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-24 right-4 md:bottom-12 md:right-12 z-[200] flex flex-col items-end">
      {isOpen && (
        <div className="w-[calc(100vw-2rem)] md:w-[400px] h-[60vh] md:h-[550px] bg-white border border-slate-200 shadow-2xl flex flex-col mb-4 reveal rounded-sm">
          {/* Header */}
          <div className="p-4 md:p-6 bg-obsidian text-white flex justify-between items-center">
            <div className="flex items-center gap-3">
              <span className="w-2 h-2 md:w-2.5 md:h-2.5 rounded-full bg-green-500 animate-pulse"></span>
              <p className="cinematic-caps text-[9px] md:text-[10px] tracking-[0.3em] font-black">Strategic Growth Assistant</p>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white/40 hover:text-white transition-all text-2xl px-4 py-2 -mr-2">×</button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 scrollbar-hide">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] md:max-w-[85%] p-4 md:p-5 text-sm md:text-lg leading-relaxed italic ${
                  m.role === 'user' 
                  ? 'bg-slate-50 text-obsidian border-r-2 md:border-r-4 border-indigo-600' 
                  : 'text-slate-800 border-l-2 md:border-l-4 border-indigo-100 pl-4 md:pl-8'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="text-indigo-900 cinematic-caps text-[8px] font-black tracking-[0.4em] animate-pulse">
                  Analyzing clinical physics...
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 md:p-6 border-t border-slate-100 bg-white">
            <div className="flex items-center gap-2 md:gap-4 border border-slate-200 p-1 md:p-2 group focus-within:border-indigo-400 transition-all">
              <input 
                className="flex-1 bg-transparent border-none outline-none p-3 md:p-4 font-mono text-base md:text-sm tracking-tight uppercase text-obsidian placeholder:text-slate-300 min-w-0"
                placeholder={quizResult ? "Discuss recovery strategy..." : "Diagnostic Query..."}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyPress={e => e.key === 'Enter' && handleSend()}
              />
              <button 
                onClick={handleSend}
                className="w-12 h-12 md:w-12 md:h-12 flex-shrink-0 flex items-center justify-center bg-obsidian text-white hover:bg-indigo-700 transition-all active:scale-90"
              >
                →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Trigger */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 md:w-16 md:h-16 bg-[#020617] text-white flex items-center justify-center shadow-[0_20px_50px_rgba(79,70,229,0.3)] hover:bg-indigo-700 transition-all group relative border border-white/20 active:scale-95 z-[210] rounded-sm"
        aria-label="Open Chat"
      >
        {!isOpen && <span className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-600 rounded-full animate-pulse border-2 border-white z-[211]"></span>}
        {isOpen ? (
           <span className="text-3xl font-light">×</span>
        ) : (
          <svg viewBox="0 0 24 24" className="w-6 h-6 md:w-8 md:h-8 fill-white stroke-none shadow-sm">
            <path d="M12 2C6.477 2 2 6.133 2 11.238c0 2.455 1.036 4.673 2.73 6.307-.156 1.343-.654 3.064-1.572 4.455 0 0 3.195.105 5.567-2.31a10.603 10.603 0 0 0 3.275.51c5.523 0 10-4.133 10-9.238S17.523 2 12 2z" />
          </svg>
        )}
      </button>
    </div>
  );
};
