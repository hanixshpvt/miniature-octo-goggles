
import React, { useState } from 'react';
import { QuizResult } from '../types';
import { useAppStore } from '../context';

interface QuizProps {
  onComplete: (result: QuizResult) => void;
  onCancel: () => void;
}

export const Quiz: React.FC<QuizProps> = ({ onComplete, onCancel }) => {
  const { setQuizResult } = useAppStore();
  const [step, setStep] = useState(0);
  const [contact, setContact] = useState({ name: '', website: '', email: '' });
  const [loading, setLoading] = useState(false);

  const steps = [
    { q: 'Clinic primary revenue recapture protocol?', opts: ['Automated Lead Sync', 'Manual Intake/Recapture', 'Passive Referral Network'] },
    { q: 'Confirmed monthly show-up procedural volume?', opts: ['>50 Procedural Starts', '20 - 50 Procedural Starts', '<20 (Recovery Priority)'] },
    { q: 'Structural intent target for extraction node?', opts: ['High-Ticket Surgical Hub', 'Injectables Margins Node', 'Full Clinical Recalibration'] }
  ];

  const handleNext = () => setStep(step + 1);

  const calculate = () => {
    setLoading(true);
    setTimeout(() => {
      const result = {
        score: 74,
        leakEstimate: 42500,
        categoryScores: { acquisition: 70, conversion: 62, retention: 88 }
      };
      setQuizResult(result); // Update Global Store
      onComplete(result);
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-obsidian flex flex-col items-center justify-center p-4 md:p-12 relative overflow-hidden">
      
      <div className="max-w-[1000px] w-full bg-white p-8 md:p-24 space-y-12 md:space-y-16 relative border border-white/5 shadow-2xl overflow-y-auto max-h-[90vh] md:max-h-none scrollbar-hide">
        
        {/* Header Terminal */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-100 pb-8 md:pb-12 gap-6 md:gap-10">
           <div className="space-y-1">
              <p className="text-[10px] md:text-[11px] cinematic-caps text-indigo-700 font-bold tracking-[0.3em] md:tracking-[0.5em]">Growth Diagnostic Node :: [SECURED]</p>
              <div className="flex items-center gap-3">
                 <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                 <p className="text-[9px] font-mono text-slate-600 font-bold uppercase">Audited_Clinical_Sync</p>
              </div>
           </div>
           <div className="h-1.5 w-full md:w-56 bg-slate-50 relative overflow-hidden">
              <div className="h-full bg-indigo-700 transition-all duration-[1000ms]" style={{ width: `${(step / (steps.length + 1)) * 100}%` }}></div>
           </div>
        </div>

        {step === 0 ? (
          <div className="space-y-12 md:space-y-20 pt-6">
            <h2 className="text-4xl md:text-6xl font-display italic font-light tracking-tighter text-obsidian uppercase">Clinical <span className="font-bold border-b-8 md:border-b-[15px] border-slate-50">Audit.</span></h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-12">
               {[
                 { label: 'Partner identity', key: 'name', ph: 'DR_NAME_SURNAME' },
                 { label: 'Domain URL', key: 'website', ph: 'HTTPS://CLINIC.COM' },
                 { label: 'Secured Data Ingest', key: 'email', ph: 'DR_NAME@SYNC.PRO' }
               ].map((f, i) => (
                 <div key={f.key} className={`space-y-3 md:space-y-4 ${i === 2 ? 'md:col-span-2' : ''}`}>
                   <label className="text-[10px] md:text-[11px] cinematic-caps font-black text-indigo-900 tracking-widest">{f.label}</label>
                   <input 
                     className="w-full bg-slate-50 border-b-2 border-slate-200 px-6 py-4 md:py-6 text-xl md:text-2xl font-bold focus:border-indigo-600 outline-none uppercase font-mono tracking-tight transition-all text-obsidian placeholder:text-slate-300" 
                     placeholder={f.ph}
                     value={(contact as any)[f.key]}
                     onChange={e => setContact({...contact, [f.key]: e.target.value})}
                   />
                 </div>
               ))}
            </div>
            
            <button 
              onClick={handleNext} 
              disabled={!contact.name || !contact.email} 
              className="btn-luxury w-full py-6 md:py-10 text-[10px] md:text-[11px] disabled:opacity-30 shadow-lg"
            >
              INITIALIZE PATIENT AUDIT terminal node ::
            </button>
          </div>
        ) : loading ? (
           <div className="py-24 md:py-40 text-center space-y-10 md:space-y-16">
              <div className="w-16 h-16 md:w-24 md:h-24 border-[3px] md:border-[4px] border-indigo-700 border-t-transparent animate-spin mx-auto shadow-indigo-100"></div>
              <p className="text-[10px] md:text-[12px] cinematic-caps animate-pulse text-indigo-950 font-black tracking-[0.5em] md:tracking-[0.7em] uppercase">Recalibrating Regional procedural demand...</p>
           </div>
        ) : step <= steps.length ? (
           <div className="space-y-12 md:space-y-24 pt-6">
              <div className="flex items-center gap-6 md:gap-10">
                 <span className="w-12 md:w-20 h-px bg-indigo-700"></span>
                 <p className="cinematic-caps text-indigo-950 font-bold text-[9px] md:text-[11px]">Strategy Protocol MOD_0{step}</p>
              </div>
              <h3 className="text-3xl md:text-5xl font-display font-light italic leading-tight text-obsidian tracking-tighter uppercase">{steps[step-1].q}</h3>
              <div className="grid grid-cols-1 gap-4 md:gap-6 pt-6">
                 {steps[step-1].opts.map(opt => (
                   <button 
                    onClick={step === steps.length ? calculate : handleNext} 
                    key={opt} 
                    className="w-full p-8 md:p-12 text-left border border-slate-200 hover:border-indigo-600 hover:bg-slate-50 transition-all group flex justify-between items-center relative active:scale-[0.98]"
                   >
                      <span className="text-xl md:text-3xl font-light italic text-slate-600 group-hover:text-obsidian leading-none uppercase">{opt}</span>
                      <div className="h-[2px] bg-slate-100 w-10 md:w-40 group-hover:w-full md:group-hover:w-40 group-hover:bg-indigo-600 transition-all duration-[800ms] absolute bottom-0 left-0"></div>
                   </button>
                 ))}
              </div>
           </div>
        ) : null}
      </div>
      
      <button 
        onClick={onCancel} 
        className="mt-12 md:mt-20 text-[10px] cinematic-caps text-white/40 hover:text-white transition-all tracking-[0.4em] md:tracking-[0.8em] font-black uppercase underline decoration-white/10 decoration-4 underline-offset-8"
      >
        [ SHUTDOWN terminal ]
      </button>
    </div>
  );
};
