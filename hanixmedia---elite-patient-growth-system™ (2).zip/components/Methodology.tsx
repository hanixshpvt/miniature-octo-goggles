
import React from 'react';

export const Methodology: React.FC = () => {
  return (
    <section className="py-24 md:py-40 lg:py-80 px-6 md:px-8 lg:px-16 bg-white relative border-y border-slate-50">
      <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-32 items-start">
        
        <div className="lg:col-span-8 space-y-16 md:space-y-32">
          <div className="space-y-8 md:space-y-12">
            <div className="flex items-center gap-6 md:gap-10">
              <span className="w-12 md:w-16 h-px bg-indigo-600"></span>
              <p className="cinematic-caps text-indigo-900 font-black text-[10px] md:text-[11px]">Clinical Recapture Methodology</p>
            </div>
            <h2 className="luxury-header italic text-obsidian text-5xl md:text-7xl">Structural <br/><span className="font-bold underline decoration-slate-100 decoration-8 underline-offset-8 md:underline-offset-10">Recapture Yield.</span></h2>
            <p className="text-xl md:text-4xl text-obsidian font-bold max-w-2xl italic leading-[1.6] md:leading-[1.8]">
              We replace standard media retainers with structural revenue recovery architecture built for high-ticket patient margin extraction.
            </p>
          </div>

          <div className="space-y-16 md:space-y-24">
            {[
              { 
                id: 'MOD_01', 
                title: 'Structural Recapture', 
                desc: 'Recalibrating procedural intent markers within your regional procedural footprint to recapture margin leaks.' 
              },
              { 
                id: 'MOD_02', 
                title: 'Show-Up Protocols', 
                desc: 'Intake triage nodes synchronized with HIPAA infrastructure to accelerate speed-to-lead and stabilize surgical yield.' 
              },
              { 
                id: 'MOD_03', 
                title: 'Equity Synchronizer', 
                desc: 'Strategic engagement of historic procedural interest markers to force re-engagement without additional media spend.' 
              }
            ].map(protocol => (
              <div key={protocol.id} className="flex flex-col md:flex-row gap-6 md:gap-12 group border-b border-slate-100 pb-12 md:pb-16">
                 <span className="text-base md:text-lg font-mono font-black text-indigo-600 group-hover:text-indigo-800 transition-all pt-2 tracking-[0.5em] uppercase">{protocol.id}</span>
                 <div className="space-y-4 md:space-y-6">
                    <h3 className="text-3xl md:text-4xl font-display font-bold italic text-obsidian uppercase tracking-tighter group-hover:text-indigo-950 transition-all">{protocol.title}</h3>
                    <p className="text-lg md:text-3xl text-slate-800 font-bold leading-[1.8] md:leading-[2.2] italic border-l-4 border-slate-50 pl-6 md:pl-10 group-hover:border-indigo-600/30 transition-all duration-1000">
                      {protocol.desc}
                    </p>
                 </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-4 lg:sticky lg:top-48 pt-8 lg:pt-0">
          <div className="p-10 lg:p-20 border border-slate-100 bg-slate-50 shadow-none space-y-12 md:space-y-16 relative overflow-hidden group">
            <h3 className="text-3xl md:text-4xl font-display font-light leading-[1.4] italic text-obsidian relative z-10">
               "Clicks represent intent; we deploy <span className="font-bold border-b-[6px] border-indigo-600/10">structural recapture node</span> logic for revenue as a clinical output."
            </h3>
            <div className="pt-8 md:pt-12 border-t border-slate-200 space-y-3 relative z-10">
               <p className="cinematic-caps text-[10px] md:text-[12px] font-black text-obsidian tracking-[0.6em]">System Architect // Hayes</p>
               <p className="text-[8px] md:text-[9px] font-mono text-slate-500 font-bold uppercase tracking-widest">Verification Node :: US_PGS_INTEGRITY_CALIB</p>
            </div>
            <div className="absolute -bottom-16 -right-16 text-[200px] md:text-[350px] font-display text-obsidian/[0.03] select-none pointer-events-none rotate-[15deg] font-black italic">
               H
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
