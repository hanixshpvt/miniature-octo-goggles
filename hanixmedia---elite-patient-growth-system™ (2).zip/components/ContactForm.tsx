
import React from 'react';

export const ContactForm: React.FC = () => {
  return (
    <div className="py-24 px-6 max-w-7xl mx-auto">
      <div className="glass rounded-[3rem] p-10 md:p-20 flex flex-col md:flex-row gap-16 overflow-hidden relative">
        <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-blue-500/10 rounded-full blur-[100px] -z-10"></div>
        
        <div className="md:w-1/2 space-y-8">
          <h2 className="text-4xl md:text-6xl font-bold font-heading leading-tight">Ready to build <span className="text-gradient">what's next?</span></h2>
          <p className="text-slate-400 text-lg leading-relaxed">
            Drop us a line to discuss your brand's growth potential. 
            Our team usually responds within 24 hours with a custom strategy overview.
          </p>
          
          <div className="space-y-4 text-slate-300">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center">📧</div>
              <span>hello@hanixmedia.com</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center">📍</div>
              <span>Global Remote HQ</span>
            </div>
          </div>
        </div>

        <div className="md:w-1/2 bg-white/5 rounded-[2rem] p-8 md:p-12 border border-white/5 space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Full Name</label>
            <input type="text" className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none transition-all" placeholder="Enter your name" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Work Email</label>
            <input type="email" className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none transition-all" placeholder="email@company.com" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Message</label>
            <textarea className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none transition-all h-32" placeholder="Tell us about your project..."></textarea>
          </div>
          <button className="w-full py-5 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl font-bold text-white shadow-xl shadow-blue-500/20 hover:scale-[1.02] active:scale-95 transition-all">
            Send Inquiry
          </button>
        </div>
      </div>
    </div>
  );
};
