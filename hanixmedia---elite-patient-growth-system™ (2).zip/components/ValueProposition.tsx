
import React from 'react';

interface Props {
  onStartQuiz: () => void;
}

export const ValueProposition: React.FC<Props> = ({ onStartQuiz }) => {
  return (
    <section className="py-24 md:py-32 px-6 md:px-16 bg-white border-y border-slate-50 grid-mask relative overflow-hidden">
      <div className="max-w-[1700px] mx-auto space-y-20 md:space-y-64">
        
        {/* Authoritative Split Header */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-48 items-center reveal">
          <div className="lg:col-span-7 space-y-8 md:space-y-12">
            <div className="flex items-center gap-8 md:gap-12">
              <span className="w-16 md:w-24 h-2 bg-indigo-600"></span>
              <p className="cinematic-caps text-indigo-900 font-black tracking-[0.5em] md:tracking-[0.6em] text-[10px] md:text-[12px]">Clinical Revenue Triage</p>
            </div>
            <h2 className="luxury-header text-obsidian italic leading-[1.1]">Strategic <br/><span className="font-bold border-b-[20px] md:border-b-[30px] border-slate-50 underline-offset-[15px] md:underline-offset-[25px]">Recapture Protocols.</span></h2>
          </div>
          <div className="lg:col-span-5 border-l-[8px] md:border-l-[12px] border-indigo-600 pl-8 md:pl-12 py-8 md:py-10 bg-slate-50">
            <p className="text-xl md:text-3xl text-obsidian font-bold italic leading-relaxed">
              We replace generic marketing hype with clinical revenue recovery infrastructure built for aesthetic margin extraction.
            </p>
          </div>
        </div>

        {/* Patient Growth System™ Pipeline diagram */}
        <div className="py-16 md:py-40 relative group border-y border-slate-100 bg-white">
          <div className="absolute inset-0 hidden md:flex items-center justify-center pointer-events-none">
            <div className="w-[90%] h-[3px] bg-slate-100 relative">
               <div className="absolute inset-0 bg-indigo-600 w-0 group-hover:w-full transition-all duration-[3s] ease-in-out"></div>
            </div>
          </div>
          <div className="relative flex flex-col md:flex-row justify-between items-center gap-16 md:gap-12 z-10 max-w-7xl mx-auto">
             {[
               { n: '01', l: 'INTENT RECAPTURE', d: 'MOD_01', sub: 'Regional intent ingestion mapping national demand markers to extraction gaps.' },
               { n: '02', l: 'TRIAGE SYNC', d: 'MOD_02', sub: 'Logistical intake triage node synchronized with U.S. clinical speed-to-lead.' },
               { n: '03', l: 'YIELD LOCK', d: 'MOD_03', sub: 'Show-up yield calibration enforcing verified procedural start appointments.' },
               { n: '04', l: 'EQUITY SYNC', d: 'MOD_04', sub: 'Reactivation of historic patient equity nodes through targeted recapture.' }
             ].map((node, i) => (
               <div key={i} className="flex flex-col items-center gap-6 md:gap-12 w-full max-w-[320px] reveal group/node text-center" style={{ transitionDelay: `${i * 200}ms` }}>
                  <div className="w-24 h-24 md:w-32 md:h-32 bg-white border-[6px] border-indigo-900 rounded-sm flex-shrink-0 flex items-center justify-center shadow-3xl transition-all duration-[1s] group-hover/node:bg-indigo-900 group-hover/node:scale-110">
                     <span className="font-mono text-3xl md:text-4xl font-black text-obsidian group-hover/node:text-white transition-colors">{node.n}</span>
                  </div>
                  <div className="space-y-3 md:space-y-4">
                     <p className="cinematic-caps text-[10px] md:text-[11px] text-indigo-700 font-black uppercase tracking-[0.4em] md:tracking-[0.5em]">{node.d}</p>
                     <p className="text-xl md:text-3xl font-display font-bold italic uppercase tracking-tighter text-obsidian leading-none">{node.l}</p>
                     <p className="text-slate-800 font-medium italic text-sm md:text-lg leading-relaxed">{node.sub}</p>
                  </div>
                  {/* Mobile connector line */}
                  {i < 3 && <div className="h-10 w-[2px] bg-indigo-600/20 md:hidden mt-2"></div>}
               </div>
             ))}
          </div>
        </div>

        {/* Qualified Lead Diagnostic logic */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-slate-200 border-2 border-slate-200 shadow-5xl rounded-sm">
          {[
            { 
              title: 'Clinical Audit 01', 
              label: 'Audit diagnostic ingress',
              text: 'Recalibrating intent markers within regional procedural footprints to identify margin extraction nodes.',
              meta: 'NODE_REF :: US_PGS_9.2'
            },
            { 
              title: 'Recapture Triage 02', 
              label: 'Logistical show-up fix',
              text: 'Advanced intake node sync synchronized with surgical hub hubs to force verify procedural show-up yield.',
              meta: 'NODE_REF :: US_PGS_42.1'
            }
          ].map((p) => (
            <article key={p.meta} className="bg-white p-10 lg:p-24 space-y-10 md:space-y-16 group hover:bg-slate-50 transition-all duration-1000">
               <span className="text-[10px] md:text-[12px] font-mono font-black text-indigo-700 tracking-[0.4em] md:tracking-[0.6em] uppercase border-l-8 border-indigo-600 pl-6 block">{p.meta}</span>
               <div className="space-y-4 md:space-y-6">
                 <p className="cinematic-caps text-indigo-950 font-black text-[10px] md:text-[12px] tracking-[0.4em] md:tracking-[0.5em] uppercase">{p.label}</p>
                 <h3 className="text-3xl md:text-6xl font-display font-bold italic text-obsidian uppercase tracking-tighter transition-all duration-700 group-hover:tracking-normal">{p.title}</h3>
               </div>
               <p className="text-xl md:text-3xl text-slate-900 font-bold leading-[1.8] italic border-l-[8px] md:border-l-[12px] border-slate-100 pl-8 md:pl-12 group-hover:border-indigo-600/30 transition-all duration-1000">
                 {p.text}
               </p>
            </article>
          ))}
        </div>

        <div className="flex flex-col items-center gap-10 md:gap-16 reveal">
           <button onClick={onStartQuiz} className="btn-luxury px-12 md:px-24 py-8 md:py-10 shadow-3xl text-[10px] md:text-[12px] tracking-[0.4em] md:tracking-[0.6em] w-full md:w-auto">Initialize diagnostic Terminal ::</button>
           <p className="cinematic-caps text-slate-500 font-black tracking-[0.6em] md:tracking-[0.8em] text-[9px] md:text-[11px] uppercase text-center">Partner Ingress node synced 2025</p>
        </div>
      </div>
    </section>
  );
};
