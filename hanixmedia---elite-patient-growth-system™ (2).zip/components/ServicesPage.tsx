
import React, { useState } from 'react';
import { PageHeader } from './Shared';
import { StrategyDepth } from './StrategyDepth';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Trash2, ShieldAlert } from 'lucide-react';
import { useAppStore } from '../context';

export const ServicesPage = () => {
  const { services, deleteService } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const filteredServices = services.filter(s => 
    s.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.desc.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = () => {
    if (deleteId) {
      deleteService(deleteId);
      setDeleteId(null);
    }
  };

  return (
    <main className="pb-24 md:pb-32 bg-white reveal min-h-screen">
      <PageHeader 
        title="Yield Extraction Protocols." 
        subtitle="Eliminating procedural intent leakage through structural named architecture synchronized with surgical show-up physics."
      />
      
      {/* Search & Filter Bar */}
      <div className="max-w-[1600px] mx-auto px-6 mb-12">
        <div className="relative group max-w-xl">
          <input 
            type="text" 
            placeholder="FILTER PROTOCOLS ::" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border-b-2 border-obsidian/20 focus:border-indigo-600 px-6 py-4 outline-none font-mono text-sm uppercase tracking-widest text-obsidian transition-all placeholder:text-slate-400"
          />
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
        </div>
      </div>

      <div className="max-w-[1600px] mx-auto grid grid-cols-1 md:grid-cols-2 gap-px bg-slate-200 border border-slate-200 relative">
        <AnimatePresence mode='popLayout'>
          {filteredServices.length > 0 ? (
            filteredServices.map(s => (
              <motion.article 
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                key={s.id} 
                className="bg-white p-8 md:p-10 lg:p-24 space-y-8 md:space-y-12 group hover:bg-slate-50 transition-all duration-700 relative overflow-hidden"
              >
                 {/* Delete Action */}
                 <button 
                   onClick={() => setDeleteId(s.id)}
                   className="absolute top-6 right-6 p-3 bg-slate-100 hover:bg-red-50 text-slate-400 hover:text-red-600 transition-all opacity-0 group-hover:opacity-100 z-20"
                   aria-label="Delete Protocol"
                 >
                   <Trash2 className="w-5 h-5" />
                 </button>

                 <div className="aspect-[16/9] overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-1000 border border-slate-100 relative">
                   <img src={s.img} alt={s.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[10s]" />
                   
                   {/* Icon Overlay with Animation & Tooltip */}
                   <div className="absolute bottom-0 right-0 bg-white p-4 border-t border-l border-slate-100 group/icon">
                      <motion.div 
                        whileHover={{ rotate: 15, scale: 1.1 }}
                        className="relative"
                      >
                         <s.Icon className="w-8 h-8 text-obsidian group-hover:text-indigo-600 transition-colors" />
                         
                         {/* Tooltip */}
                         <div className="absolute bottom-full right-0 mb-4 w-48 bg-obsidian text-white text-[10px] p-3 uppercase tracking-widest font-bold opacity-0 group-hover/icon:opacity-100 transition-opacity pointer-events-none z-30">
                            {s.tooltip}
                            <div className="absolute bottom-[-4px] right-4 w-2 h-2 bg-obsidian rotate-45"></div>
                         </div>
                      </motion.div>
                   </div>
                 </div>

                 <div className="space-y-4">
                   <div className="flex items-center justify-between">
                     <p className="cinematic-caps text-indigo-700 font-black tracking-[0.4em] text-[10px] md:text-[11px]">{s.label}</p>
                   </div>
                   <h3 className="text-3xl md:text-4xl font-display font-bold italic text-obsidian uppercase tracking-tighter transition-all">{s.title}</h3>
                 </div>
                 <p className="text-lg md:text-2xl text-slate-800 leading-[1.8] font-light italic border-l-4 border-slate-100 group-hover:border-indigo-600 pl-6 md:pl-8 transition-all">
                   {s.desc}
                 </p>
              </motion.article>
            ))
          ) : (
            <div className="col-span-full py-32 text-center text-slate-400 font-mono text-sm tracking-widest uppercase bg-white">
              No protocols found matching criteria ::
            </div>
          )}
        </AnimatePresence>
      </div>
      
      {/* Confirmation Dialog */}
      <AnimatePresence>
        {deleteId && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-obsidian/80 backdrop-blur-sm"
              onClick={() => setDeleteId(null)}
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white p-10 md:p-16 max-w-lg w-full relative z-30 border-2 border-slate-100 shadow-2xl"
            >
              <div className="flex flex-col items-center text-center space-y-8">
                <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center">
                  <ShieldAlert className="w-10 h-10 text-red-600" />
                </div>
                <div className="space-y-4">
                  <h3 className="text-2xl font-display font-bold text-obsidian uppercase tracking-tight">Confirm Deletion</h3>
                  <p className="text-slate-500 font-light leading-relaxed">
                    Are you sure you want to dismantle this extraction protocol? This action cannot be undone and may impact revenue yield.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4 w-full">
                  <button 
                    onClick={() => setDeleteId(null)}
                    className="py-4 border border-slate-200 text-slate-600 font-bold uppercase tracking-widest text-[10px] hover:bg-slate-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleDelete}
                    className="py-4 bg-red-600 text-white font-bold uppercase tracking-widest text-[10px] hover:bg-red-700 transition-colors shadow-lg shadow-red-500/20"
                  >
                    Confirm Delete
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      
      <StrategyDepth />
    </main>
  );
};
