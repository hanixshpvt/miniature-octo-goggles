
import React from 'react';

export const PageHeader = ({ title, subtitle }: { title: string, subtitle: string }) => (
  <header className="space-y-6 md:space-y-12 mb-12 md:mb-32 pt-8 md:pt-24 reveal px-6 max-w-[1600px] mx-auto">
    <div className="flex items-center gap-4 md:gap-8">
      <span className="w-8 md:w-16 h-1 bg-indigo-600"></span>
      <p className="cinematic-caps text-obsidian font-black text-[9px] md:text-[10px] tracking-[0.3em] md:tracking-[0.4em]">US Clinical Verification node :: US_PGS_9.2</p>
    </div>
    <h1 className="luxury-header italic text-obsidian leading-[1.05] text-4xl md:text-[6.5rem]">{title}</h1>
    <p className="text-lg md:text-2xl text-slate-800 max-w-3xl font-light italic border-l-4 md:border-l-[8px] border-indigo-600 pl-6 md:pl-16 leading-relaxed bg-slate-50 p-5 md:p-8">
      {subtitle}
    </p>
  </header>
);

export const BrandCredibility = () => (
  <div className="py-20 md:py-32 border-y border-slate-100 bg-white reveal">
    <div className="max-w-[1600px] mx-auto px-6 space-y-10 md:space-y-20">
      <div className="text-center space-y-4">
        <p className="cinematic-caps text-indigo-900 font-bold text-[10px] md:text-[11px] tracking-[0.4em] uppercase">Structural Partner Credibility</p>
        <h3 className="text-2xl md:text-3xl font-display font-light italic text-obsidian uppercase tracking-tighter">Trusted by Elite U.S. Surgical Hubs</h3>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-px bg-slate-200 border border-slate-200">
        
        {/* LOGO 1: NEW YORK AESTHETIC */}
        <div className="bg-white p-6 md:p-10 flex items-center justify-center hover:bg-slate-50 transition-colors h-32 md:h-40 group relative overflow-hidden">
           <div className="opacity-60 md:opacity-50 group-hover:opacity-100 transition-all duration-700 group-hover:scale-105">
              <div className="flex flex-col items-center">
                <span className="font-display font-bold text-xl md:text-2xl tracking-widest uppercase text-obsidian">VOGUE</span>
                <div className="flex items-center gap-2 w-full justify-between">
                    <span className="h-px bg-obsidian w-full"></span>
                    <span className="font-sans text-[7px] md:text-[8px] tracking-[0.2em] font-bold text-slate-500 uppercase whitespace-nowrap">NY MEDICAL</span>
                    <span className="h-px bg-obsidian w-full"></span>
                </div>
              </div>
           </div>
        </div>

        {/* LOGO 2: BEVERLY HILLS SURGERY */}
        <div className="bg-white p-6 md:p-10 flex items-center justify-center hover:bg-slate-50 transition-colors h-32 md:h-40 group">
           <div className="opacity-60 md:opacity-50 group-hover:opacity-100 transition-all duration-700 group-hover:scale-105 flex items-center gap-2 md:gap-3">
              <div className="w-8 h-8 md:w-10 md:h-10 border-2 border-obsidian rounded-full flex items-center justify-center font-display italic font-bold text-lg md:text-xl">B</div>
              <div className="flex flex-col">
                 <span className="font-sans text-[8px] md:text-[10px] tracking-[0.2em] font-bold text-obsidian uppercase leading-none">BEVERLY HILLS</span>
                 <span className="font-display text-base md:text-lg italic text-slate-600 lowercase leading-none">dermatology</span>
              </div>
           </div>
        </div>

        {/* LOGO 3: MIAMI PLASTIC */}
        <div className="bg-white p-6 md:p-10 flex items-center justify-center hover:bg-slate-50 transition-colors h-32 md:h-40 group">
           <div className="opacity-60 md:opacity-50 group-hover:opacity-100 transition-all duration-700 group-hover:scale-105 text-center">
               <svg viewBox="0 0 50 50" className="w-6 h-6 md:w-8 md:h-8 mx-auto mb-2 fill-obsidian">
                   <path d="M25 0 L50 25 L25 50 L0 25 Z M25 10 L40 25 L25 40 L10 25 Z" />
               </svg>
               <span className="font-display font-light text-lg md:text-xl tracking-[0.2em] text-obsidian uppercase block">MIAMI</span>
           </div>
        </div>

        {/* LOGO 4: CHICAGO AESTHETIC */}
        <div className="bg-white p-6 md:p-10 flex items-center justify-center hover:bg-slate-50 transition-colors h-32 md:h-40 group">
           <div className="opacity-60 md:opacity-50 group-hover:opacity-100 transition-all duration-700 group-hover:scale-105 border-l-2 border-r-2 border-obsidian px-4 md:px-6 py-1">
              <span className="font-sans text-xl md:text-2xl font-black tracking-tighter text-obsidian block leading-none">ARCANA</span>
              <span className="font-sans text-[8px] md:text-[9px] tracking-[0.3em] text-slate-500 block text-center uppercase">SURGICAL</span>
           </div>
        </div>

         {/* LOGO 5: DALLAS LASER */}
         <div className="bg-white p-6 md:p-10 flex items-center justify-center hover:bg-slate-50 transition-colors h-32 md:h-40 group">
           <div className="opacity-60 md:opacity-50 group-hover:opacity-100 transition-all duration-700 group-hover:scale-105 flex flex-col items-end">
              <span className="font-display font-black italic text-2xl md:text-3xl tracking-tight text-obsidian leading-none">ÉLAN</span>
              <span className="font-sans text-[7px] md:text-[8px] tracking-[0.2em] bg-obsidian text-white px-1 font-bold uppercase">MedSpa Dallas</span>
           </div>
        </div>

      </div>
    </div>
  </div>
);
    