
import React from 'react';

export const ExclusionCriteria: React.FC = () => {
  return (
    <section className="py-32 px-6 bg-obsidian text-white border-y border-white/10 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-900/20 blur-[150px] rounded-full pointer-events-none"></div>
      
      <div className="max-w-[1400px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-20 items-center relative z-10">
        <div className="lg:col-span-5 space-y-10">
           <div className="flex items-center gap-6">
              <span className="w-3 h-3 bg-red-500 animate-pulse rounded-full shadow-[0_0_15px_rgba(239,68,68,0.5)]"></span>
              <p className="cinematic-caps text-red-500 font-black tracking-[0.4em] text-[11px]">ACCESS DENIED PROTOCOLS</p>
           </div>
           <h2 className="text-5xl md:text-7xl font-display italic font-light leading-[1.1] tracking-tight">
             Who We <br/><span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-800">Do Not</span> Serve.
           </h2>
           <p className="text-xl md:text-2xl text-slate-400 font-light leading-relaxed border-l-4 border-red-900/50 pl-8">
             Our architecture is calibrated exclusively for high-ticket surgical & medical aesthetic hubs. We repel 95% of the market to protect the yield of the top 5%.
           </p>
        </div>

        <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-px bg-white/10 border border-white/10">
           {[
             {
               title: "Commodity Clinics",
               desc: "If you compete on price (Groupon model) rather than clinical authority, our yield architecture will fail.",
               icon: "×"
             },
             {
               title: "Low-Ticket Volume",
               desc: "We do not service spas focused on facials or low-margin entry services. Surgical & Injectable focus only.",
               icon: "×"
             },
             {
               title: "Generalist Agencies",
               desc: "We are not a 'full service' shop. We do not do organic social, blog posts, or logo design. We only do Revenue.",
               icon: "×"
             },
             {
               title: "No Sales Infrastructure",
               desc: "If you lack a dedicated front-desk team to handle verified patient intake, do not apply.",
               icon: "×"
             }
           ].map((item, idx) => (
             <div key={idx} className="bg-[#0b0f1f] p-12 space-y-6 group hover:bg-[#111629] transition-colors duration-500">
                <div className="text-4xl font-light text-red-500/50 group-hover:text-red-500 transition-colors font-display italic">{item.icon}</div>
                <h3 className="text-2xl font-display font-bold text-slate-200 tracking-wide uppercase">{item.title}</h3>
                <p className="text-slate-400 text-lg leading-relaxed">{item.desc}</p>
             </div>
           ))}
        </div>
      </div>
    </section>
  );
};
