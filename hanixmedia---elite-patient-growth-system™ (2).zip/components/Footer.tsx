import React from 'react';

interface FooterProps {
  onStartQuiz?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onStartQuiz }) => {
  return (
    <footer className="py-32 md:py-64 px-6 lg:px-12 bg-white border-t border-slate-50 relative overflow-hidden">
      <div className="max-w-[1700px] mx-auto grid grid-cols-1 md:grid-cols-12 gap-16 md:gap-32">
        
        <div className="md:col-span-5 space-y-16">
           <div className="flex items-center gap-6">
            <div className="w-16 h-16 border border-slate-100 flex items-center justify-center group cursor-pointer transition-all hover:border-indigo-600 shadow-sm bg-white">
               <svg viewBox="0 0 100 100" className="w-11 h-11">
                  <path d="M50 5 L95 50 L50 95 L5 50 Z" className="stroke-obsidian group-hover:stroke-indigo-600 transition-all stroke-[8] fill-none" />
                  <path d="M50 25 L75 50 L50 75 L25 50 Z" className="fill-obsidian group-hover:fill-indigo-600 transition-all" />
               </svg>
            </div>
            <div className="flex flex-col -space-y-1">
              <span className="text-3xl font-display font-black italic uppercase text-obsidian tracking-tighter">Hanix<span className="text-indigo-600 font-light">Media</span></span>
              <span className="text-[9px] cinematic-caps text-slate-400 font-black tracking-[0.6em]">Growth Architecture™</span>
            </div>
          </div>
          <p className="text-slate-500 text-3xl font-light italic leading-[2.0] max-w-lg">
            Strategic patient growth partners for elite U.S. surgeons. Recovery sync node verified 2025.
          </p>
          <div className="flex items-center gap-8 opacity-40 grayscale transition-all hover:grayscale-0 hover:opacity-100 duration-1000 pt-6">
             <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span className="text-[10px] cinematic-caps font-bold">HIPAA SYNC SECURE</span>
             </div>
             <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-indigo-600"></div>
                <span className="text-[10px] cinematic-caps font-bold">PGS VERIFIED</span>
             </div>
          </div>
        </div>

        <div className="md:col-span-7 grid grid-cols-2 lg:grid-cols-3 gap-16 md:gap-24 text-[11px] cinematic-caps font-black tracking-[0.6em] text-slate-400 uppercase">
           <div className="space-y-10">
             <h4 className="text-obsidian pb-4 border-b border-slate-50 font-black tracking-[1em]">Systems</h4>
             <ul className="space-y-8">
               <li><button onClick={() => window.location.hash = 'services'} className="hover:text-indigo-600 transition-all">Protocols</button></li>
               <li><button onClick={() => window.location.hash = 'cases'} className="hover:text-indigo-600 transition-all">Evidence hub</button></li>
               <li><button onClick={() => window.location.hash = 'about'} className="hover:text-indigo-600 transition-all">Consultancy</button></li>
             </ul>
           </div>
           <div className="space-y-10">
             <h4 className="text-obsidian pb-4 border-b border-slate-50 font-black tracking-[1em]">Partner</h4>
             <ul className="space-y-8">
               <li className="cursor-default">Yield sync</li>
               <li className="cursor-default">Recapture Node</li>
               <li className="cursor-default">Audit Ingest</li>
             </ul>
           </div>
           <div className="space-y-10">
             <h4 className="text-obsidian pb-4 border-b border-slate-50 font-black tracking-[1em]">Ingress</h4>
             <ul className="space-y-8">
               <li><button onClick={() => window.location.hash = 'contact'} className="italic underline text-indigo-950 font-black decoration-indigo-600 decoration-[4px]">Initialize Audit</button></li>
               <li className="cursor-default">Secure terminal</li>
             </ul>
           </div>
        </div>
      </div>

      <div className="mt-48 pt-20 border-t border-slate-50 flex flex-col md:flex-row justify-between items-center text-[10px] cinematic-caps font-black text-slate-300 tracking-[0.8em] uppercase text-center md:text-left gap-12">
        <p>© 2025 HANIXMEDIA // ELITE CLINIC GROWTH // U.S. PERFORMANCE ARCHITECTURE</p>
        <p>SECURE_NODE_SYNCED // US_ PGS_ 09.2</p>
      </div>

      {/* Optimized Mobile Sticky CTA */}
      <div className="fixed bottom-0 left-0 w-full lg:hidden bg-indigo-950 text-white p-6 flex items-center justify-center z-[110] border-t border-indigo-900 shadow-5xl">
         <button onClick={onStartQuiz} className="w-full py-5 text-[12px] cinematic-caps font-black tracking-[0.5em] uppercase border border-white/10 hover:bg-indigo-900 transition-colors">
           Unlock Growth Audit →
         </button>
      </div>
    </footer>
  );
};