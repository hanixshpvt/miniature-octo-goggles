
import React from 'react';
import { QuizResult } from '../types';

interface Props {
  result: QuizResult;
  onReset: () => void;
}

export const Results: React.FC<Props> = ({ result, onReset }) => {
  const formattedLeak = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(result.leakEstimate);

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-8 md:p-14 py-40 relative overflow-hidden grid-mask">
      
      <div className="max-w-[1500px] w-full bg-white p-10 md:p-24 lg:p-32 space-y-24 shadow-5xl relative border border-slate-100 reveal">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-24 items-end border-b border-slate-200 pb-24">
           <div className="lg:col-span-7 space-y-16">
              <div className="flex items-center gap-10">
                <span className="w-24 h-2 bg-indigo-600"></span>
                <p className="cinematic-caps text-indigo-950 font-black text-[13px] tracking-[0.8em] uppercase">Clinical Diagnostic Prescription node :: VERIFIED_PGS</p>
              </div>
              <h1 className="luxury-header text-obsidian italic leading-[0.9]">
                Recapture Yield: <br/><span className="font-bold text-indigo-700">{result.score}<span className="text-obsidian italic font-light">/100</span></span>
              </h1>
           </div>
           <div className="lg:col-span-5 bg-slate-50 p-16 border border-slate-200 space-y-8 shadow-xl relative">
              <div className="absolute top-0 left-0 w-3 h-full bg-red-600"></div>
              <p className="cinematic-caps text-[11px] text-slate-500 font-black tracking-[0.8em] uppercase">Est. Regional Margin Recapture Node</p>
              <p className="text-8xl md:text-9xl font-black font-display text-obsidian tracking-tighter leading-none">
                {formattedLeak}<span className="text-red-600 italic tracking-tighter">+</span>
              </p>
              <div className="pt-10 border-t border-slate-100 flex items-center gap-6">
                 <div className="w-4 h-4 rounded-full bg-red-600 animate-pulse"></div>
                 <p className="text-[12px] cinematic-caps text-red-600 font-black tracking-[0.5em] uppercase">Structural procedural Extraction Gaps detected</p>
              </div>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-24">
           {[
             { label: 'Intent Extraction physics', score: result.categoryScores.acquisition, meta: 'Structural Recapture synchronization' },
             { label: 'Procedural recovery node', score: result.categoryScores.conversion, meta: 'Recalibrating Clinical recapture logic' },
             { label: 'Calendar Yield health', score: result.categoryScores.retention, meta: 'Syncing historical show-up equity' }
           ].map(c => (
             <div key={c.label} className="space-y-12 group">
                <div className="flex justify-between items-end text-[12px] cinematic-caps font-black pb-6 border-b border-slate-200 group-hover:border-indigo-600 transition-colors">
                   <span className="text-slate-500 tracking-[0.2em]">{c.label}</span>
                   <span className="text-obsidian tracking-[0.4em]">{Math.floor(c.score)}%</span>
                </div>
                <div className="h-4 bg-slate-100 relative overflow-hidden border border-slate-50 shadow-inner">
                   <div className="h-full bg-indigo-950 shadow-[0_0_30px_rgba(79,70,229,0.5)] transition-all duration-[4s] ease-in-out" style={{ width: `${c.score}%` }}></div>
                </div>
                <p className="text-[11px] cinematic-caps text-slate-400 font-bold tracking-[0.5em] uppercase italic">{c.meta}</p>
             </div>
           ))}
        </div>

        {/* Action routing logic based on score triage */}
        <div className="bg-obsidian text-white p-14 md:p-32 lg:p-40 space-y-24 relative overflow-hidden group border border-white/10 rounded-sm">
           <div className="absolute top-0 right-0 p-32 text-[260px] font-display text-white/[0.04] rotate-[15deg] pointer-events-none select-none italic font-black uppercase tracking-tighter">TRIAGE</div>
           
           <div className="space-y-20 relative z-10">
              <h3 className="text-6xl md:text-7xl font-display italic font-light leading-none uppercase">Prescription <span className="font-bold underline decoration-indigo-600 decoration-[20px] underline-offset-[25px]">Recalibration:</span></h3>
              
              <div className="space-y-24">
                {result.score >= 75 ? (
                  <div className="space-y-24">
                    <p className="text-3xl md:text-5xl text-slate-200 font-bold leading-[1.6] max-w-6xl border-l-[16px] border-indigo-600 pl-16 py-10 italic tracking-tight bg-white/[0.03]">
                      Diagnostic status: <span className="text-white underline decoration-indigo-600/30 decoration-[10px]">ELITE EXTRACTION READY.</span> Primary regional recapture thresholds detected. Partner verification Hub live for procedural recovery nodes.
                    </p>
                    <div className="flex flex-col xl:flex-row gap-8 pt-12">
                       <button className="px-24 py-10 bg-indigo-600 text-white cinematic-caps font-black text-[14px] shadow-3xl hover:bg-white hover:text-black transition-all duration-700 tracking-[0.5em] btn-glow">
                         Request revenue triage Access Node <span className="ml-10">→</span>
                       </button>
                       <button className="px-24 py-10 border-2 border-white/20 text-white cinematic-caps font-black text-[14px] hover:bg-white/5 transition-all duration-1000 tracking-[0.5em]">
                         Initialize Hub Recapture Demo node ::
                       </button>
                       <button className="px-24 py-10 bg-white text-obsidian cinematic-caps font-black text-[14px] hover:bg-indigo-50 transition-all duration-700 tracking-[0.5em] shadow-xl border border-white/20 flex items-center justify-center group/demo">
                          <span className="w-3 h-3 bg-red-600 rounded-full animate-pulse mr-6 shadow-red-500/50 shadow-lg group-hover/demo:bg-red-500"></span>
                          Live Platform Walkthrough
                       </button>
                    </div>
                  </div>
                ) : result.score >= 50 ? (
                  <div className="space-y-24">
                    <p className="text-3xl md:text-4xl text-slate-200 font-light leading-[1.8] max-w-6xl border-l-[12px] border-white/10 pl-16 py-10 italic bg-white/[0.03]">
                      Recapture intent loss synchronized. Structural show-up latency exceeding clinical bypass thresholds by <span className="text-white font-bold decoration-indigo-600/30 underline decoration-[6px]">+$65,000 extraction gaps.</span> Synchronization required to initialize Hub capture nodes.
                    </p>
                    <button className="px-24 py-10 bg-indigo-600 text-white cinematic-caps font-black text-[13px] hover:bg-white hover:text-black transition-all duration-1000 shadow-5xl tracking-[0.5em]">
                      Watch: How We stabilized Surgical recurrence nodes <span className="ml-10">→</span>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-24">
                    <p className="text-3xl md:text-4xl text-slate-200 font-light leading-[1.8] max-w-6xl border-l-[12px] border-white/10 pl-16 py-10 italic bg-white/[0.03]">
                      Structural Recapture Hub failure. Current Ingestion Protocol node leaking margin yield. <span className="text-white font-bold border-b border-indigo-600">Recovery Synchronicity Requirement: SYSTEM RECALIBRATION REQUIRED.</span>
                    </p>
                    <button className="px-24 py-10 border-2 border-white/20 text-white cinematic-caps font-black text-[13px] hover:bg-white hover:text-black transition-all duration-1000 tracking-[0.5em]">
                      Download diagnostic clinical Recovery Ledger node <span className="ml-10">↓</span>
                    </button>
                  </div>
                )}
              </div>
           </div>
        </div>

        <button onClick={onReset} className="text-[13px] cinematic-caps text-slate-400 hover:text-indigo-950 transition-all font-black tracking-[1.2em] block w-full text-center py-20 border-t border-slate-100 hover:bg-slate-50 uppercase shadow-inner">Shutdown diagnostic terminal nodes ::</button>
      </div>
    </div>
  );
};
    